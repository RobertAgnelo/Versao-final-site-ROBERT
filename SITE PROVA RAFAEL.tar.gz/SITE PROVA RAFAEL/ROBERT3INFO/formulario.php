 <form action="/action_page.php">
  <div class="form-group">
    <label for="email">EMAIL</label>
    <input type="email" class="form-control" id="email "name="email">
  </div>

 <label for="email">NOME</label>
    <input type="email" class="form-control" id="name "name="name">
  </div>

 <label for="email">TELEFONE</label>
    <input type="email" class="form-control" id="fone "name="fone">
  </div>

 <label for="email">DESCRIÇÃO</label>
    <textarea type="email" class="form-control" id="descrição "name="descrição"></textarea>
  </div>

   <button type="submit" class="btn btn-primary">Submit</button>
</form> 
